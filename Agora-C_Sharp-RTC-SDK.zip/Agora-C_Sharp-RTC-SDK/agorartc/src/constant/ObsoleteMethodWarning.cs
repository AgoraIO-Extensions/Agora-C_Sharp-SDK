//  ObsoleteMethodWarning.cs
//
//  Created by YuGuo Chen on October 6, 2021.
//
//  Copyright © 2021 Agora. All rights reserved.
//

namespace agora.rtc
{
    internal static partial class ObsoleteMethodWarning
    {
        internal const string GeneralWarning = "This method is deprecated.";
    }
}